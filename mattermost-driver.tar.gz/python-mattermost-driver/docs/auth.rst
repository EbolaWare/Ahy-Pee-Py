Authentication
''''''''''''''
Yuu can either use the normal ways for login, by token and or username,
or authenticate using the .netrc file. This passes the credentials to the
requests library, where you can also read more about that.

A nice example for authentication with .netrc by `@apfeiffer <https://github.com/apfeiffer1>`_.

.. literalinclude:: mmDriverTokenAuthExample.py
