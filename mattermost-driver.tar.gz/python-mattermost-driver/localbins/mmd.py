from mattermostdriver import Driver

doo = Driver({
	'url': 'localhost',
	'token': '9xdizs8ohj8gfkgjysgft1o68e',
	'scheme': 'http',
	'port': 8065,
	'basepath': '/api/v4',
	'timeout': 30,
	'request_timeout': None,
	'debug': False
})
doo.login()

"""
If the api request needs additional parameters
you can pass them to the function in the following way:
- Path parameters are always simple parameters you pass to the function
"""
new_users = ["zzz1","zzz2","zzz3","zzz4","zzz5"]
maildomain = "@mattermost.local"
new_users_id = []
user = {
  "email": "",
  "username": "",
  "password": "password",
  "notify_props": {
    "email": "false",
    "push": "false",
    "desktop": "true",
    "desktop_sound": "false",
    "mention_keys": "false",
    "channel": "false",
    "first_name": "false"
  }
}
for new_user in new_users:
	user['email'] = new_user+maildomain
	user['username'] = new_user
	new_users_id.append(doo.users.create_user(options=user)['id'])
	

# - Query parameters are always passed by passing a `params` dict to the function
doo.teams.get_teams()

# See the mattermost api documentation to see which parameters you need to pass.
doo.channels.create_channel(options={
	'team_id': 'some_team_id',
	'name': 'awesome-channel',
	'display_name': 'awesome channel',
	'type': 'O'
})

"""
If you want to make a websocket connection to the mattermost server
you can call the init_websocket method, passing an event_handler.
Every Websocket event send by mattermost will be send to that event_handler.
See the API documentation for which events are available.
"""
doo.init_websocket(event_handler)

# To upload a file you will need to pass a `files` dictionary
channel_id = doo.channels.get_channel_by_name_and_team_name('team', 'channel')['id']
file_id = doo.files.upload_file(
	channel_id=channel_id
	files={'files': (filename, open(filename))}
)['file_infos'][0]['id']


# track the file id and pass it in `create_post` options, to attach the file
doo.posts.create_post(options={
	'channel_id': channel_id,
	'message': 'This is the important file',
	'file_ids': [file_id]})

# If needed, you can make custom requests by calling `make_request`
doo.client.make_request('post', '/endpoint', options=None, params=None, data=None, files=None, basepath=None)

# If you want to call a webhook/execute it use the `call_webhook` method.
# This method does not exist on the mattermost api AFAIK, I added it for ease of use.
doo.webhooks.call_webhook('myHookId', options) # Options are optional
