#!/usr/bin/python2
import requests,json
import sys.argv as args
var = {'email':'@subdomain.domain'}
mm = {'host': 'http://localhost:8065/api/v4/'}
mm['users'] = mm['host']+'users'
mm['teams'] = mm['host']+'teams'
with open("/home/mint/.api/mattermost.json",'r') as file:
    mm['key'] = json.load(file)['Access Token']
print mm['key']
mm['headers'] = {'Authorization': 'Bearer '+mm['key']}
mm['userdata'] = {
  "email": "",
  "username": "",
  "password": "password",
  "notify_props": {
    "email": "false",
    "push": "false",
    "desktop": "true",
    "desktop_sound": "false",
    "mention_keys": "false",
    "channel": "false",
    "first_name": "false"
  }
}

def mm_get_teams():
	teams = requests.get(mm['teams'], headers=mm['headers'] )
	

def push_user(uname):
    mm['userdata'['email']] = uname+'@subdomain.domain'
    mm['userdata'['username']] = uname
    new_user = requests(post,mm['host'],headers=mm['headers'],json=user)
    return new_user

def push_user_2_team(uname):
    requests(get, mm['teams'], headers=mm['headers'])
        
"""
for u_thing in args():
    print push_user(u_thing)
    print push_user_2_team(u_thing)
"""
