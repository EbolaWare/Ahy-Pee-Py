full_version = '6.3.1'
short_version = '.'.join(full_version.split('.', 2)[:2])
